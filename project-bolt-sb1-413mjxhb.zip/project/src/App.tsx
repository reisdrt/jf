import React from 'react';
import { 
  BookOpen, 
  TrendingUp, 
  Brain, 
  Monitor, 
  Smartphone, 
  DollarSign, 
  Target, 
  BarChart3,
  Gift,
  Star,
  ArrowRight,
  CheckCircle,
  Lightbulb,
  Users,
  Zap,
  Award,
  MessageCircle,
  Video,
  FileText,
  Eye
} from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      {/* Header */}
      <header className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-600/20 via-transparent to-green-600/20"></div>
        <div className="relative container mx-auto px-4 py-16 text-center">
          <div className="mb-8">
            <h1 className="text-5xl md:text-7xl font-bold bg-gradient-to-r from-yellow-400 to-yellow-600 bg-clip-text text-transparent mb-4">
              Renda Extra Inteligente
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
              O guia simples e direto para lucrar com internet, mesmo sem experiência
            </p>
          </div>
          
          <div className="flex justify-center items-center space-x-6 mb-12">
            <div className="flex items-center space-x-2 text-yellow-400">
              <TrendingUp className="w-6 h-6" />
              <span className="text-lg font-semibold">Métodos Comprovados</span>
            </div>
            <div className="flex items-center space-x-2 text-green-400">
              <CheckCircle className="w-6 h-6" />
              <span className="text-lg font-semibold">Resultados Reais</span>
            </div>
            <div className="flex items-center space-x-2 text-blue-400">
              <Zap className="w-6 h-6" />
              <span className="text-lg font-semibold">Rápido e Prático</span>
            </div>
          </div>

          <div className="relative max-w-md mx-auto">
            <div className="absolute inset-0 bg-gradient-to-r from-yellow-600 to-green-600 rounded-2xl blur-xl opacity-30 animate-pulse"></div>
            <div className="relative bg-gradient-to-r from-yellow-600 to-green-600 p-8 rounded-2xl shadow-2xl">
              <BookOpen className="w-16 h-16 mx-auto mb-4 text-black" />
              <h3 className="text-2xl font-bold text-black mb-2">eBook Completo</h3>
              <p className="text-black/80">7 Capítulos + Bônus Exclusivos</p>
            </div>
          </div>
        </div>
      </header>

      {/* Apresentação */}
      <section className="py-20 bg-gradient-to-b from-gray-900 to-black">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-4xl font-bold mb-6 text-yellow-400">Minha História</h2>
              <div className="w-24 h-1 bg-gradient-to-r from-yellow-400 to-green-400 mx-auto rounded-full"></div>
            </div>
            
            <div className="bg-gray-800/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm">
              <div className="flex items-center justify-center mb-6">
                <div className="w-20 h-20 bg-gradient-to-r from-yellow-400 to-green-400 rounded-full flex items-center justify-center">
                  <Users className="w-10 h-10 text-black" />
                </div>
              </div>
              
              <div className="space-y-6 text-gray-300 leading-relaxed text-lg">
                <p>
                  <strong className="text-yellow-400">Olá! Eu me chamo Reis</strong> e, assim como muita gente, já passei por momentos em que o dinheiro não dava nem para o básico. Cheguei a pensar que renda extra era coisa de quem já tinha muito tempo livre ou seguidores na internet… mas estava totalmente enganado.
                </p>
                
                <p>
                  Tudo começou quando eu decidi parar de depender apenas do meu salário (ou ajuda de familiares). Comecei a estudar formas simples de ganhar dinheiro pela internet, testando várias estratégias: algumas não funcionaram, outras me surpreenderam.
                </p>
                
                <p>
                  Com esforço, constância e as ferramentas certas, consegui transformar o meu celular em uma fonte de renda diária, trabalhando de casa — e hoje ensino outras pessoas a fazerem o mesmo, mesmo que estejam começando do zero, como eu comecei.
                </p>
                
                <div className="bg-gradient-to-r from-green-600/20 to-yellow-600/20 p-6 rounded-2xl border border-green-600/30">
                  <p className="text-white font-semibold">
                    Este eBook é o guia que eu gostaria de ter tido quando comecei. Nele, eu compartilho os métodos mais eficazes, sem enrolação, que realmente funcionam para gerar renda extra — mesmo se você tiver pouco tempo ou dinheiro para investir.
                  </p>
                </div>
                
                <p className="text-center text-xl font-bold text-yellow-400">
                  Se você aplicar o que está aqui, os resultados virão. Boa leitura e, principalmente, mão na massa!
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Aviso Importante */}
      <section className="py-16 bg-gradient-to-r from-red-900/30 to-orange-900/30">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="bg-black/70 p-8 rounded-3xl border border-orange-500/50 backdrop-blur-sm">
              <div className="text-center mb-6">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-full mb-4">
                  <Eye className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-3xl font-bold text-orange-400 mb-4">Antes de tudo, quero te dar um conselho simples:</h3>
              </div>
              
              <div className="space-y-6 text-gray-200 leading-relaxed">
                <p className="text-2xl font-bold text-center text-yellow-400">
                  Não pare no meio do caminho.
                </p>
                
                <p className="text-lg">
                  Esse eBook não é só mais um conteúdo genérico da internet — ele foi feito para transformar sua forma de pensar e agir sobre dinheiro e liberdade financeira.
                </p>
                
                <p className="text-lg">
                  Tudo o que você precisa para começar a ganhar renda extra de verdade, com estratégias práticas e possíveis, está aqui.
                  E o melhor: você não precisa ser expert, nem ter dinheiro para investir.
                </p>
                
                <div className="bg-gradient-to-r from-yellow-600/20 to-green-600/20 p-6 rounded-2xl border border-yellow-600/30">
                  <p className="text-xl font-semibold text-center text-white">
                    Só peço uma coisa: leia até o final.
                  </p>
                  <p className="text-center mt-2">
                    Pode ser esse o conteúdo que vai virar a chave da sua vida financeira — e te mostrar um caminho que ninguém nunca te ensinou.
                  </p>
                </div>
                
                <p className="text-2xl font-bold text-center text-gradient bg-gradient-to-r from-yellow-400 to-green-400 bg-clip-text text-transparent">
                  Vamos juntos até o fim? 💰🔥
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Capítulos */}
      <section className="py-20 bg-black">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-yellow-400 to-green-400 bg-clip-text text-transparent">
              Conteúdo Completo
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              7 capítulos detalhados com estratégias práticas e comprovadas para sua transformação financeira
            </p>
            <div className="w-32 h-1 bg-gradient-to-r from-yellow-400 to-green-400 mx-auto rounded-full mt-8"></div>
          </div>

          <div className="grid gap-8 md:gap-12">
            {/* Capítulo 1 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-yellow-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center">
                  <Lightbulb className="w-8 h-8 text-black" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-yellow-400 mb-4">
                    💡 CAPÍTULO 1 — O Que é Renda Extra e Por Que Você Precisa Dela
                  </h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Diferença entre renda ativa e passiva</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Por que depender só de um salário é perigoso</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>A crise atual e a busca por segurança financeira</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Capítulo 2 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-purple-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl flex items-center justify-center">
                  <Brain className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-purple-400 mb-4">
                    🧠 CAPÍTULO 2 — Mente Milionária: Comece com o Pensamento Certo
                  </h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como eliminar crenças limitantes</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Hábitos financeiros saudáveis</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Foco, consistência e disciplina</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Capítulo 3 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-blue-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center">
                  <Monitor className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-blue-400 mb-4">
                    💻 CAPÍTULO 3 — 10 Maneiras Reais e Atuais de Ganhar Renda Extra Online
                  </h3>
                  <div className="grid md:grid-cols-2 gap-3 text-gray-300">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Marketing de Afiliados (Hotmart, Kiwify, Eduzz)</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Venda de infoprodutos</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Freelancer (design, copy, tráfego)</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Social media para empresas</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Revenda de produtos físicos</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>YouTube Shorts + monetização</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>TikTok com link de afiliado</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Loja no Instagram/WhatsApp</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Aulas particulares online</span>
                    </div>
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>PLRs prontos (eBooks para revenda)</span>
                    </div>
                  </div>
                  <div className="mt-4 p-4 bg-blue-900/30 rounded-xl border border-blue-500/30">
                    <p className="text-blue-300 font-semibold">
                      Para cada método: como começar, quanto pode ganhar e dicas práticas
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Capítulo 4 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-green-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center">
                  <Smartphone className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-green-400 mb-4">
                    📲 CAPÍTULO 4 — Estratégias de Divulgação Para Vender Todos os Dias
                  </h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como atrair tráfego gratuito (Instagram, TikTok, Kwai, YouTube)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como usar grupos de Facebook e WhatsApp</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Noções de tráfego pago (opcional)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como criar autoridade mesmo sendo iniciante</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Capítulo 5 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-yellow-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-yellow-500 to-amber-500 rounded-2xl flex items-center justify-center">
                  <DollarSign className="w-8 h-8 text-black" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-yellow-400 mb-4">
                    💰 CAPÍTULO 5 — Dicas de Produtos Que Mais Vendem
                  </h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Nichos que mais convertem (renda extra, emagrecimento, sedução, ansiedade)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como escolher bons produtos na Hotmart, Eduzz, Kiwify</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como analisar uma página de vendas</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Capítulo 6 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-orange-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-orange-500 to-red-500 rounded-2xl flex items-center justify-center">
                  <Target className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-orange-400 mb-4">
                    🛠️ CAPÍTULO 6 — Ferramentas Gratuitas e Úteis Para Iniciantes
                  </h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Canva (design)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>CapCut (vídeos para redes)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Notion ou Trello (organização)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Linktree ou link na bio (para afiliados)</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Sites de IA para criar conteúdo</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            {/* Capítulo 7 */}
            <div className="bg-gradient-to-r from-gray-800/50 to-gray-900/50 p-8 rounded-3xl border border-gray-700/50 backdrop-blur-sm hover:border-emerald-500/50 transition-all duration-300">
              <div className="flex items-start space-x-6">
                <div className="flex-shrink-0 w-16 h-16 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center">
                  <BarChart3 className="w-8 h-8 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-emerald-400 mb-4">
                    📈 CAPÍTULO 7 — Como Multiplicar Seus Resultados com Constância
                  </h3>
                  <ul className="space-y-3 text-gray-300">
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Técnicas para não desistir</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Como medir o que está funcionando</span>
                    </li>
                    <li className="flex items-center space-x-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span>Construir uma audiência aos poucos</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Bônus */}
      <section className="py-20 bg-gradient-to-b from-black to-gray-900">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
              🎁 Bônus Exclusivos
            </h2>
            <p className="text-xl text-gray-400 max-w-3xl mx-auto">
              Materiais extras para acelerar ainda mais seus resultados
            </p>
            <div className="w-32 h-1 bg-gradient-to-r from-pink-400 to-purple-400 mx-auto rounded-full mt-8"></div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-gradient-to-br from-pink-600/20 to-purple-600/20 p-6 rounded-3xl border border-pink-500/30 hover:border-pink-500/60 transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-pink-500 to-purple-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <Gift className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-pink-400 mb-3 text-center">Bônus Final</h3>
              <p className="text-gray-300 text-center">Conteúdo exclusivo para potencializar seus ganhos</p>
            </div>

            <div className="bg-gradient-to-br from-blue-600/20 to-cyan-600/20 p-6 rounded-3xl border border-blue-500/30 hover:border-blue-500/60 transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <FileText className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-blue-400 mb-3 text-center">Início do seu eBook</h3>
              <p className="text-gray-300 text-center">Template pronto para começar seu próprio produto</p>
            </div>

            <div className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 p-6 rounded-3xl border border-green-500/30 hover:border-green-500/60 transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-green-500 to-emerald-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <MessageCircle className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-bold text-green-400 mb-3 text-center">Posts para Redes</h3>
              <p className="text-gray-300 text-center">Conteúdo pronto para suas redes sociais</p>
            </div>

            <div className="bg-gradient-to-br from-yellow-600/20 to-orange-600/20 p-6 rounded-3xl border border-yellow-500/30 hover:border-yellow-500/60 transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-2xl flex items-center justify-center mb-4 mx-auto">
                <Video className="w-8 h-8 text-black" />
              </div>
              <h3 className="text-xl font-bold text-yellow-400 mb-3 text-center">Vídeo com IA</h3>
              <p className="text-gray-300 text-center">Avatar personalizado para suas vendas</p>
            </div>
          </div>

          <div className="mt-12 bg-gradient-to-r from-purple-600/20 to-pink-600/20 p-8 rounded-3xl border border-purple-500/30 max-w-4xl mx-auto">
            <div className="text-center">
              <Award className="w-16 h-16 mx-auto mb-4 text-purple-400" />
              <h3 className="text-2xl font-bold text-purple-400 mb-4">Storytelling para Conexão</h3>
              <p className="text-gray-300 text-lg">
                Aprenda a criar histórias que geram conexão emocional com seu público e aumentam drasticamente suas conversões
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-yellow-600/20 via-green-600/20 to-blue-600/20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-5xl md:text-6xl font-bold mb-8 bg-gradient-to-r from-yellow-400 via-green-400 to-blue-400 bg-clip-text text-transparent">
              Transforme Sua Vida Financeira Hoje
            </h2>
            
            <p className="text-2xl text-gray-300 mb-12 leading-relaxed">
              Não deixe para amanhã a oportunidade de construir sua independência financeira. 
              Este guia completo tem tudo que você precisa para começar a ganhar renda extra de verdade.
            </p>

            <div className="grid md:grid-cols-3 gap-8 mb-12">
              <div className="bg-black/50 p-6 rounded-2xl border border-yellow-500/30">
                <Star className="w-12 h-12 mx-auto mb-4 text-yellow-400" />
                <h3 className="text-xl font-bold text-yellow-400 mb-2">Métodos Testados</h3>
                <p className="text-gray-300">Estratégias que realmente funcionam no mercado atual</p>
              </div>
              
              <div className="bg-black/50 p-6 rounded-2xl border border-green-500/30">
                <Zap className="w-12 h-12 mx-auto mb-4 text-green-400" />
                <h3 className="text-xl font-bold text-green-400 mb-2">Resultados Rápidos</h3>
                <p className="text-gray-300">Comece a ver resultados em poucas semanas</p>
              </div>
              
              <div className="bg-black/50 p-6 rounded-2xl border border-blue-500/30">
                <Users className="w-12 h-12 mx-auto mb-4 text-blue-400" />
                <h3 className="text-xl font-bold text-blue-400 mb-2">Para Iniciantes</h3>
                <p className="text-gray-300">Não precisa de experiência prévia ou investimento alto</p>
              </div>
            </div>

            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-600 to-green-600 rounded-3xl blur-xl opacity-50 animate-pulse"></div>
              <button className="relative bg-gradient-to-r from-yellow-500 to-green-500 hover:from-yellow-600 hover:to-green-600 text-black text-2xl font-bold py-6 px-12 rounded-3xl shadow-2xl transform hover:scale-105 transition-all duration-300 flex items-center space-x-4 mx-auto">
                <span>QUERO TRANSFORMAR MINHA VIDA</span>
                <ArrowRight className="w-8 h-8" />
              </button>
            </div>

            <p className="text-gray-400 mt-8 text-lg">
              ✅ Acesso imediato • ✅ Garantia de satisfação • ✅ Suporte completo
            </p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-black border-t border-gray-800">
        <div className="container mx-auto px-4 text-center">
          <div className="mb-6">
            <h3 className="text-3xl font-bold bg-gradient-to-r from-yellow-400 to-green-400 bg-clip-text text-transparent mb-2">
              Renda Extra Inteligente
            </h3>
            <p className="text-gray-400">O guia que vai mudar sua relação com o dinheiro</p>
          </div>
          
          <div className="flex justify-center items-center space-x-8 mb-8">
            <div className="flex items-center space-x-2 text-yellow-400">
              <CheckCircle className="w-5 h-5" />
              <span>Conteúdo Original</span>
            </div>
            <div className="flex items-center space-x-2 text-green-400">
              <CheckCircle className="w-5 h-5" />
              <span>Métodos Atualizados</span>
            </div>
            <div className="flex items-center space-x-2 text-blue-400">
              <CheckCircle className="w-5 h-5" />
              <span>Suporte Incluído</span>
            </div>
          </div>
          
          <p className="text-gray-500">
            © 2024 Renda Extra Inteligente. Todos os direitos reservados.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;